# Form Companion

Version 0.2.1 — a standalone local developer build.

## Install

1. Extract the ZIP, or open this extension's folder from the complete suite.
2. Open `chrome://extensions` in desktop Chrome and enable **Developer mode**.
3. Click **Load unpacked** and choose the folder containing this extension's `manifest.json`.
4. Pin the extension in the puzzle-piece menu and click its toolbar icon to open the side panel.

Requires Chrome 116 or newer. No build step, account, API key, or subscription is needed. Chrome's AI requirements apply separately to Explain This Page.

For page access, click the toolbar icon while on the website. If you navigate to another website, click the icon again to grant access there. No permanent website host permissions are requested. Chrome internal pages, incognito, and local files are not supported.

## Use it

Save a named answer such as an introduction, then use Copy when you need it. Answers can be edited, searched, and deleted. Add document names to the checklist and tick them off; actual documents are never stored.

To fill a website field: open the website, click the extension's toolbar icon, click **Scan this page's fields**, choose a field and an answer, then click **Fill selected field**. This replaces that field's current contents and dispatches input/change events, without submitting the form. Review the result before submitting on the website. Scan again after navigation or a form layout change.

Field guidance comes from simple label rules, not AI. Scanning reads labels and field types, not current field values. Filling supports visible, enabled text/email/tel/url/search inputs and textareas in the top-level document. Password fields, OTP autocomplete fields, and common payment fields are excluded. This is not a universal sensitive-data detector. Cross-origin frames, shadow DOM, custom editors, and some complex forms are unsupported. Avoid saving passwords or payment details as reusable answers.

## Data, backups, and permissions

All records stay in this Chrome profile, without cloud sync or analytics. There are no remote scripts or application backends. Uninstalling removes local data; export a backup first. Chrome's local-storage quota applies. Sensitive URLs and notes may appear in plain-text backups. Clipboard operations occur only on explicit Copy actions. Page capture/scanning/filling occurs only on the corresponding button actions.

Export backup downloads JSON. Import backup accepts this extension's version 1 format (under 16 MB, subject to available Chrome local storage) and adds records without replacing existing ones. Importing twice creates duplicates. Undo last deletion restores the most recently deleted item during this Chrome session, including after closing/reopening the panel. It will not overwrite an existing item. Export backups for longer-term recovery. Unfinished forms are saved temporarily per browser window in Chrome session storage; use Clear unsaved draft to reset them. Browser exit or extension reload/update can clear session drafts and undo history. Screenshots and template placeholder values are excluded from draft recovery. Reading drafts preserve source URL/title alongside the passage. Imported backup dates are preserved; imports still assign new record IDs.

Permissions:

- `storage`: save records and user-controlled backups in this Chrome profile.
- `sidePanel`: display the interface beside the page.
- `activeTab`: temporarily access the current website after the toolbar icon is clicked.
- `scripting`: read the explicitly requested page information or fill a field the user chooses.

## Release status

This is an unpacked developer build, not a published Chrome Web Store extension. Publishing still requires a developer account, confirmed publisher name, listing assets, privacy disclosures, manual testing in a normal Chrome installation, and Google review. The ZIP has `manifest.json` at its root for future store upload preparation.

See the suite's TEST-REPORT.txt for what was tested and its limits.

## New in 0.2.0

Reusable answers support {{name}} and {{company}} placeholders (letters, numbers, underscores, and spaces; start with a letter). Use template lets you enter values and preview the prepared answer before copying/filling. Missing values block filling. Values remain in this panel only. Up to 20 different placeholders are interactive; answers with more placeholders remain accessible as plain text for legacy compatibility. Prepared answers are limited to 10,000 characters.

## Fixed in 0.2.1

Backup imports support up to 16 MB and preserve record dates. Form submissions block concurrent edits and duplicate submission. See the suite release notes for extension-specific fixes.
