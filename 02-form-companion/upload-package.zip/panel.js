import {$,el,notify,on,submit,action,required,text,inject,currentTab,copy,records,save,remove,search,card,empty,init} from './common.js';
import {templateKeys,resolveTemplate} from './formats.js';
let scan=null,activeTemplate='',templateValues=new Map();
function isTemplate(answer){const count=templateKeys(answer).length;return count>0&&count<=20;}
function prepared(answer){return templateKeys(answer).length>20?answer:resolveTemplate(answer,templateValues);}
function updatePreview(){try{$('template-preview').textContent=prepared(activeTemplate)||'Choose a saved answer.';}catch(error){$('template-preview').textContent=error.message;}}
async function refreshTemplate(){const item=(await records()).find(item=>item.kind==='answer'&&item.id===$('saved-answer').value);activeTemplate=item?.answer||'';$('variables').replaceChildren();const keys=templateKeys(activeTemplate);if(keys.length>20)$('variables').append(el('p','hint','This answer has more than 20 placeholders and is kept as plain text. Edit it to use fewer placeholders.'));for(const key of keys.length<=20?keys:[]){const label=el('label','',key);const input=document.createElement('input');input.maxLength=1000;input.value=templateValues.get(key)||'';input.placeholder=`Value for ${key}`;input.addEventListener('input',()=>{templateValues.set(key,input.value);updatePreview();});label.append(input);$('variables').append(label);}updatePreview();}
function schema(raw){if(raw.kind==='task')return {kind:'task',label:required(raw.label,'Task'),done:raw.done===true};if(raw.kind!=='answer')throw Error('Unknown item type.');const answer=required(raw.answer,'Answer',5000);templateKeys(answer);return {kind:'answer',label:required(raw.label,'Answer name',100),answer};}
// This function is serialized into the website. It never reads field contents.
function formFields(fill){
 const allowed=new Set(['text','email','tel','url','search']);
 const fields=[...document.querySelectorAll('input,textarea')].filter(e=>{
  const tokens=(e.autocomplete||'').toLowerCase();
  const label=[e.id,e.name,e.getAttribute('aria-label'),...[...(e.labels||[])].map(l=>l.innerText)].join(' ').toLowerCase();
  return !e.disabled&&!e.readOnly&&e.getClientRects().length>0&&(e.tagName==='TEXTAREA'||allowed.has(e.type))&&!/cc-|one-time-code|password/.test(tokens)&&!/(credit.?card|card.?number|cvv|cvc|security.?code|password|social.?security|\bssn\b|\botp\b)/.test(label);
 });
 const describe=(e,index)=>({index,signature:[e.tagName,e.type,e.id,e.name,e.placeholder].join('|'),label:([...(e.labels||[])].map(l=>l.innerText).join(' ').trim()||e.getAttribute('aria-label')||e.placeholder||e.name||e.id||`Field ${index+1}`).slice(0,180),type:e.type||'text'});
 if(!fill){const token=[...crypto.getRandomValues(new Uint32Array(4))].map(value=>value.toString(16).padStart(8,'0')).join('');globalThis.__formCompanionScanV1={token,fields,url:location.href};return {fields:fields.map(describe),url:location.href,token};}
 const target=fields[fill.index];
 const scanned=globalThis.__formCompanionScanV1;
 if(!target||!scanned||scanned.token!==fill.token||scanned.url!==location.href||scanned.fields[fill.index]!==target||describe(target,fill.index).signature!==fill.signature||describe(target,fill.index).label!==fill.label)return {error:'The form changed. Scan its fields again.'};
 const proto=target.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
 Object.getOwnPropertyDescriptor(proto,'value').set.call(target,fill.value);
 target.dispatchEvent(new Event('input',{bubbles:true}));target.dispatchEvent(new Event('change',{bubbles:true}));target.focus();target.scrollIntoView({block:'center',behavior:'smooth'});
 return {ok:true};
}
function explainField(){const option=$('field').selectedOptions[0];const label=(option?.textContent||'').toLowerCase();let help='Enter the information requested by this field. Check any instructions shown by the website.';
 if(/cover.?letter|motivation/.test(label))help='Briefly explain why you want this opportunity and how your experience fits it.';
 else if(/postal|zip/.test(label))help='Use the postal code associated with the address requested by the website.';
 else if(/phone|mobile|telephone/.test(label))help='Use a number where you can be reached. Include your country code if the website requests it.';
 else if(/email/.test(label))help='Use an email address you check regularly.';
 else if(/first.?name|given.?name/.test(label))help='Enter your given name, matching the documents requested by the website.';
 else if(/last.?name|surname|family.?name/.test(label))help='Enter your surname or family name.';
 else if(/url|website|portfolio|linkedin/.test(label))help='Enter the complete website address, including https://.';
 $('field-help').textContent=help+' Guidance uses simple label rules.';
}
submit('answer-form',async()=>{const id=$('answer-id').value;const previous=id?(await records()).find(x=>x.id===id):{};await save({...previous,id:id||undefined,kind:'answer',label:$('label').value,answer:$('answer').value});$('answer-form').reset();$('answer-id').value='';$('cancel-edit').hidden=true;notify('Answer saved.');});
on('cancel-edit',async()=>{$('answer-form').reset();$('answer-id').value='';$('cancel-edit').hidden=true;});
submit('task-form',async()=>{await save({kind:'task',label:$('task').value,done:false});$('task').value='';notify('Checklist item added.');});
on('scan',async()=>{const captured=await inject(formFields,[null]);scan={tabId:captured.tab.id,...captured.result};$('field').replaceChildren();for(const field of scan.fields){const option=el('option','',field.label);option.value=String(field.index);$('field').append(option);}if(!scan.fields.length){$('field').append(el('option','','No supported fields found'));$('field').value='';} $('page-name').textContent=new URL(scan.url).hostname+` · ${scan.fields.length} supported fields`;explainField();notify('Scanned field labels. Passwords and common payment fields are excluded.');});
$('field').addEventListener('change',explainField);
on('fill',async()=>{const field=scan?.fields.find(item=>String(item.index)===$('field').value);if(!field)throw Error('Scan the page and choose a field first.');const answer=(await records()).find(item=>item.kind==='answer'&&item.id===$('saved-answer').value);if(!answer)throw Error('Choose a saved answer first.');
 const tab=await currentTab();if(tab.id!==scan.tabId||tab.url!==scan.url)throw Error('The page changed. Scan its fields again.');
 const value=prepared(answer.answer);const {result}=await inject(formFields,[{...field,value,token:scan.token}]);if(result?.error)throw Error(result.error);notify('Field filled. Review it on the website.');
});
$('search').addEventListener('input',()=>render().catch(e=>notify(e.message,true)));
async function render(){const all=await records();const answers=all.filter(x=>x.kind==='answer');const selected=$('saved-answer').value;$('saved-answer').replaceChildren();for(const item of answers){const option=el('option','',item.label);option.value=item.id;$('saved-answer').append(option);}if(answers.some(item=>item.id===selected))$('saved-answer').value=selected;await refreshTemplate();
 const shown=search(answers,$('search').value);$('answers').replaceChildren();if(!shown.length)empty($('answers'),'Your reusable answers will appear here.');for(const item of shown){const c=card(item.label);c.append(el('p','note',item.answer));const actions=el('div','actions');actions.append(action(isTemplate(item.answer)?'Use template':'Copy',async()=>{if(isTemplate(item.answer)){templateValues=new Map();$('saved-answer').value=item.id;await refreshTemplate();$('variables').scrollIntoView({block:'center'});notify('Fill the placeholder values, then copy or fill the prepared answer.');}else await copy(item.answer);}),action('Edit',async()=>{$('answer-id').value=item.id;$('label').value=item.label;$('answer').value=item.answer;$('cancel-edit').hidden=false;$('label').focus();}),action('Delete',()=>remove(item),'subtle danger'));c.append(actions);$('answers').append(c);}
 $('tasks').replaceChildren();for(const item of all.filter(x=>x.kind==='task')){const row=el('div','check');const label=el('label','check');const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=item.done;checkbox.addEventListener('change',()=>save({...item,done:checkbox.checked}).catch(e=>notify(e.message,true)));label.append(checkbox,document.createTextNode(item.label));row.append(label,action('Remove',()=>remove(item),'subtle danger'));$('tasks').append(row);}
}
$('saved-answer').addEventListener('change',()=>{templateValues=new Map();refreshTemplate().catch(e=>notify(e.message,true));});
on('copy-prepared',()=>{if(!activeTemplate)throw Error('Choose a saved answer first.');return copy(prepared(activeTemplate));});
init('form-companion',schema,render).catch(e=>notify(e.message,true));
