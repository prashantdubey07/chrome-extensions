async function configurePanel() {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}
chrome.runtime.onInstalled.addListener(() => configurePanel().catch(console.error));
chrome.runtime.onStartup.addListener(() => configurePanel().catch(console.error));
