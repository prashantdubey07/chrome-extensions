import {PREFIX, webUrl, normalizeWorkspace, parseBackup, matches} from './model.js';
const $ = id => document.getElementById(id);
let tabs = [], workspaces = [], deleted = null, busy = false, draftKey='';
function captureDraft(){if(draftKey)chrome.storage.session.set({[draftKey]:{name:$('name').value,note:$('note').value}}).catch(error=>notify(error.message,true));}
async function recovery(){const window=await chrome.windows.getCurrent();draftKey='workspace-draft:'+window.id;const data=await chrome.storage.session.get([draftKey,'deletedWorkspace']);if(data[draftKey]){$('name').value=data[draftKey].name||'';$('note').value=data[draftKey].note||'';}if(data.deletedWorkspace){deleted=data.deletedWorkspace;notify('A workspace was deleted. Undo is available.');}for(const id of ['name','note'])$(id).addEventListener('input',captureDraft);}
function notify(message, error = false) {
  $('status').hidden = false; $('status').classList.toggle('error', error);
  $('status-text').textContent = message; $('undo').hidden = !deleted || error;
}
function element(tag, className, text) { const el = document.createElement(tag); if (className) el.className = className; if (text) el.textContent = text; return el; }
function updateSelection() {
  const count = $('tabs').querySelectorAll(':checked').length;
  $('tab-summary').textContent = `${count} of ${tabs.length} web tabs selected`;
  $('save').disabled = busy || count === 0;
}
async function refreshTabs() {
  tabs = (await chrome.tabs.query({currentWindow: true})).filter(tab => !tab.incognito && webUrl(tab.pendingUrl || tab.url));
  $('tabs').replaceChildren();
  for (const tab of tabs) {
    const label = element('label', 'tab'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.value = String(tab.id); checkbox.checked = true;
    checkbox.addEventListener('change', updateSelection); const title = tab.title || tab.url;
    label.append(checkbox, element('span', '', title)); label.title = tab.pendingUrl || tab.url; $('tabs').append(label);
  }
  updateSelection();
}
async function loadWorkspaces() {
  const data = await chrome.storage.local.get(null);
  workspaces = Object.entries(data).filter(([key]) => key.startsWith(PREFIX)).map(([, value]) => value).sort((a,b) => Number(b.pinned===true)-Number(a.pinned===true)||b.createdAt.localeCompare(a.createdAt));
  render();
}
function render() {
  $('count').textContent = String(workspaces.length); $('workspaces').replaceChildren();
  const found = workspaces.filter(workspace => matches(workspace, $('search').value));
  if (!found.length) {
    const empty = element('div', 'empty'); empty.append(element('strong', '', workspaces.length ? 'No matches yet.' : 'Your next session starts here.'), element('span', '', workspaces.length ? 'Try a different name, note, or website.' : 'Save a few tabs and leave a note for future you.')); $('workspaces').append(empty);
  }
  for (const workspace of found) {
    const card = element('article', 'card'); card.append(element('h3', '', workspace.name));
    card.append(element('p', 'meta', `${workspace.tabs.length} tab${workspace.tabs.length === 1 ? '' : 's'} · ${new Date(workspace.createdAt).toLocaleDateString(undefined,{month:'short', day:'numeric', year:'numeric'})}`));
    if (workspace.note) { const note = element('p', 'next'); note.append(element('strong', '', 'YOUR NEXT STEP'), document.createTextNode(workspace.note)); card.append(note); }
    const actions = element('div', 'actions'); const resume = element('button', 'resume', 'Resume in new window ↗'); resume.type = 'button';
    const edit = element('button', 'resume', 'Edit'); edit.type='button';
    const pin = element('button', 'resume', workspace.pinned?'Unpin':'Pin'); pin.type='button';pin.setAttribute('aria-label',`${workspace.pinned?'Unpin':'Pin'} ${workspace.name}`);
    pin.addEventListener('click',async()=>{pin.disabled=true;try{const key=PREFIX+workspace.id;const data=await chrome.storage.local.get(key);if(!data[key])throw Error('This workspace was deleted.');await chrome.storage.local.set({[key]:{...data[key],pinned:!data[key].pinned}});}catch(error){notify(error.message,true);}finally{pin.disabled=false;}});
    const editor=element('form','workspace-editor');editor.hidden=true;
    const nameLabel=element('label','','Workspace name');const nameInput=document.createElement('input');nameInput.required=true;nameInput.maxLength=80;nameInput.value=workspace.name;nameLabel.append(nameInput);
    const noteLabel=element('label','','Next-step note');const noteInput=document.createElement('textarea');noteInput.maxLength=2000;noteInput.value=workspace.note;noteLabel.append(noteInput);
    const commit=element('button','resume','Save changes');commit.type='submit';const cancel=element('button','delete','Cancel');cancel.type='button';cancel.addEventListener('click',()=>editor.hidden=true);
    editor.append(nameLabel,noteLabel,commit,cancel);edit.addEventListener('click',()=>{editor.hidden=!editor.hidden;if(!editor.hidden)nameInput.focus();});
    editor.addEventListener('submit',async event=>{event.preventDefault();commit.disabled=true;try{const key=PREFIX+workspace.id;const data=await chrome.storage.local.get(key);if(!data[key])throw Error('This workspace was deleted.');const name=nameInput.value.trim();if(!name)throw Error('A workspace name is required.');await chrome.storage.local.set({[key]:{...data[key],name,note:noteInput.value}});notify('Workspace updated. Saved tabs are kept.');}catch(error){notify(error.message,true);}finally{commit.disabled=false;}});
    resume.addEventListener('click', async () => {
      resume.disabled = true;
      try { const urls = workspace.tabs.map(tab => webUrl(tab.url)); if (urls.some(url => !url)) throw new Error('This workspace contains an unsupported URL.'); await chrome.windows.create({url: urls, focused:true}); notify(`Opened “${workspace.name}”. Your next step is saved here.`); }
      catch (error) { notify(`Could not restore: ${error.message}`, true); } finally { resume.disabled = false; }
    });
    const remove = element('button', 'delete', 'Delete'); remove.type = 'button'; remove.setAttribute('aria-label', `Delete ${workspace.name}`);
    remove.addEventListener('click', async () => { remove.disabled = true; try { await chrome.storage.session.set({deletedWorkspace:workspace});await chrome.storage.local.remove(PREFIX + workspace.id); deleted = workspace; await loadWorkspaces(); notify(`Deleted “${workspace.name}”.`); } catch (error) { notify(error.message, true); remove.disabled = false; } });
    actions.append(resume, edit, pin, remove); card.append(actions,editor); $('workspaces').append(card);
  }
}
$('save-form').addEventListener('submit', async event => {
  event.preventDefault(); if (busy) return; busy = true; updateSelection();
  try {
    const selected = new Set([...$('tabs').querySelectorAll(':checked')].map(input => Number(input.value)));
    // Recheck live tabs so closed or navigated pages are never silently saved from an old list.
    const live = await chrome.tabs.query({currentWindow:true});
    const chosen = live.filter(tab => selected.has(tab.id) && !tab.incognito && webUrl(tab.pendingUrl || tab.url));
    const changed = chosen.some(tab => {
      const original = tabs.find(item => item.id === tab.id);
      return webUrl(original?.pendingUrl || original?.url) !== webUrl(tab.pendingUrl || tab.url);
    });
    if (chosen.length !== selected.size || changed) throw new Error('Some selected tabs changed or closed. Refresh tabs and try again.');
    const workspace = normalizeWorkspace({name:$('name').value, note:$('note').value, tabs:chosen.map(tab => ({title:tab.title, url:tab.pendingUrl || tab.url}))});
    await chrome.storage.local.set({[PREFIX + workspace.id]:workspace});
    $('name').value = ''; $('note').value = ''; await loadWorkspaces(); notify(`Saved “${workspace.name}”. See you when you’re ready.`);
  } catch (error) { notify(`Could not save: ${error.message}`, true); }
  finally { busy = false; updateSelection();captureDraft(); }
});
$('search').addEventListener('input', render);
for (const [id, checked] of [['select-all', true], ['select-none', false]]) $(''+id).addEventListener('click', () => { for (const input of $('tabs').querySelectorAll('input')) input.checked = checked; updateSelection(); });
$('refresh').addEventListener('click', () => refreshTabs().catch(error => notify(error.message,true)));
$('undo').addEventListener('click', async () => { if (!deleted) return; try { const key=PREFIX+deleted.id;const existing=await chrome.storage.local.get(key);if(existing[key])throw Error('This workspace already exists; it was not overwritten.');await chrome.storage.local.set({[key]:deleted});await chrome.storage.session.remove('deletedWorkspace');deleted = null; await loadWorkspaces(); notify('Workspace restored.'); } catch (error) { notify(error.message,true); } });
$('export').addEventListener('click', async () => {
  try { await loadWorkspaces(); const blob = new Blob([JSON.stringify({format:'where-was-i', version:1, workspaces})],{type:'application/json'}); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `where-was-i-${new Date().toISOString().slice(0,10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 10000); notify('Backup created. It contains your saved URLs and notes.'); }
  catch (error) { notify(error.message,true); }
});
$('import').addEventListener('click', () => $('import-file').click());
$('import-file').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return;
  try { if (file.size > 16 * 1024 * 1024) throw new Error('Backup must be smaller than 16 MB.'); const incoming = parseBackup(await file.text()); await chrome.storage.local.set(Object.fromEntries(incoming.map(workspace => [PREFIX + workspace.id,workspace]))); await loadWorkspaces(); notify(`Imported ${incoming.length} workspaces. Existing workspaces kept.`); }
  catch (error) { notify(`Could not import: ${error.message}`,true); } finally { event.target.value = ''; }
});
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && Object.keys(changes).some(key => key.startsWith(PREFIX))) loadWorkspaces().catch(error => notify(error.message,true)); });
Promise.all([refreshTabs(),loadWorkspaces(),recovery()]).catch(error => notify(`Could not load: ${error.message}`,true));
