export const PREFIX = 'workspace:';
export function webUrl(value) {
  try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) ? url.href : null; }
  catch { return null; }
}
export function normalizeWorkspace(raw) {
  if (!raw || typeof raw.name !== 'string' || !raw.name.trim() || !Array.isArray(raw.tabs)) throw new Error('Invalid workspace in backup.');
  if (raw.tabs.length > 500) throw new Error('A workspace can contain at most 500 tabs.');
  const tabs = raw.tabs.map(tab => {
    const url = webUrl(tab?.url);
    if (!url) throw new Error('Backup contains an unsupported URL. Only http and https are allowed.');
    return {url, title: String(tab.title || url).slice(0, 500)};
  });
  if (!tabs.length) throw new Error('A workspace must contain at least one web tab.');
  const createdAt = typeof raw.createdAt === 'string' && Number.isFinite(Date.parse(raw.createdAt)) ? new Date(raw.createdAt).toISOString() : new Date().toISOString();
  return {id: crypto.randomUUID(), name: raw.name.trim().slice(0, 80), note: String(raw.note || '').slice(0, 2000), tabs, createdAt, pinned:raw.pinned===true};
}
export function parseBackup(text) {
  const backup = JSON.parse(text);
  if (backup?.format !== 'where-was-i' || backup.version !== 1 || !Array.isArray(backup.workspaces)) throw new Error('Choose a Where was I? version 1 backup.');
  return backup.workspaces.map(normalizeWorkspace);
}
export function matches(workspace, query) {
  return [workspace.name, workspace.note, ...workspace.tabs.flatMap(tab => [tab.title, tab.url])].join(' ').toLowerCase().includes(query.trim().toLowerCase());
}
