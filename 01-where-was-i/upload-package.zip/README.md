# Where was I?

A local Chrome extension that saves a set of web tabs with a note about your next step. Version 0.2.1, the first of six planned extensions.

## Install in Chrome

1. Extract the ZIP if you downloaded the packaged version.
2. Open `chrome://extensions` in Chrome 116 or newer.
3. Turn on **Developer mode** in the top-right corner.
4. Click **Load unpacked** and select the `01-where-was-i` folder containing `manifest.json`.
5. Open Chrome's Extensions menu (the puzzle piece), pin **Where was I?**, and click its icon to open the side panel.

No build command, API key, account, or subscription is required.

## Use it

Open a few websites in one window. Give your workspace a name and an optional next-step note. Expand the tab selector to choose which tabs to save, then click **Save workspace**. The original tabs stay open.

Search names, notes, tab titles, and URLs. **Resume in new window** opens the saved pages together; your next-step note remains on its workspace card. Delete removes a saved workspace; **Undo** restores the most recently deleted workspace during this Chrome session, including after reopening the panel.

Use **Refresh tabs** after opening, closing, or navigating tabs while the panel is open. If a selected tab changed or closed, saving stops and asks for a refresh.

**Export backup** downloads a JSON file. **Import backup** adds workspaces without replacing existing ones. Importing the same backup twice creates duplicates. Imports must use the version 1 backup format, be under 16 MB, and contain workspaces with 1–500 web tabs each. Backups use compact JSON so exported files fit within the import limit for Chrome’s normal local-storage quota. Chrome's local storage quota also applies.

## Privacy and permissions

- `tabs`: read tab titles and URLs to let you choose and save them.
- `storage`: save workspaces locally in this Chrome profile.
- `sidePanel`: show the workspace interface beside your pages.

The extension has no analytics, remote scripts, network requests, content scripts, or backend. It does not read page bodies, passwords, cookies, or form fields. Chrome fetches websites normally when you restore them. Tab URLs can contain private information; exported backups contain those URLs and your notes in plain text.

Workspaces stay in this Chrome profile, without cloud sync. Uninstalling the extension removes its local data: export a backup first. Incognito support is intentionally disabled. Only HTTP and HTTPS tabs are saved; Chrome settings, new tabs, local files, and other browser-internal pages are excluded.

## Scope of this version

Saves URLs, titles, notes, and creation dates. Restoring opens URLs; it does not restore scroll positions, unsent forms, login sessions, tab groups, or navigation history. Edit changes a workspace’s name/note while keeping its tabs. Pin keeps important workspaces above unpinned ones. New-workspace name/note drafts recover in the same browser window during this Chrome session; browser exit or extension reload/update may clear drafts and undo history. Scheduled reminders are not included. This is a locally loadable developer build, not a Chrome Web Store release.

## Validation

Tested as an actually loaded Manifest V3 extension in an isolated Chrome for Testing profile: save, persistence after reload, search, multi-tab restore, delete/undo, export/import, unsupported URL rejection, literal rendering of HTML-like titles/notes, closed/navigated tab handling, empty selection, and a narrow panel layout. Toolbar side-panel behavior is verified through the Chrome API; the toolbar click itself still needs a manual check in your Chrome installation.
