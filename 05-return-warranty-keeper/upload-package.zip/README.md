# Return & Warranty Keeper

Version 0.2.1 — a standalone local developer build.

## Install

1. Extract the ZIP, or open this extension's folder from the complete suite.
2. Open `chrome://extensions` in desktop Chrome and enable **Developer mode**.
3. Click **Load unpacked** and choose the folder containing this extension's `manifest.json`.
4. Pin the extension in the puzzle-piece menu and click its toolbar icon to open the side panel.

Requires Chrome 116 or newer. No build step, account, API key, or subscription is needed. Chrome's AI requirements apply separately to Explain This Page.

For page access, click the toolbar icon while on the website. If you navigate to another website, click the icon again to grant access there. No permanent website host permissions are requested. Chrome internal pages, incognito, and local files are not supported.

## Use it

Add an item, store, optional product/order URL, purchase date, and at least one deadline: last return date or warranty end date. Confirm dates yourself against the store's policy; the extension does not infer eligibility or read receipts. You may capture the current page's title and URL by clicking the toolbar icon and then **Use this page's title & URL**.

Choose a reminder lead time of 1, 3, or 7 days. For active purchases, reminders run at 9 AM local time on the reminder day, for each deadline. Edit a purchase to update its dates, notes, or status. Returned and Archived items stop reminders. Search purchases or filter by status. Countdown labels compare calendar dates, so daylight-saving transitions do not shift the day count.

Reminders use Chrome alarms and local notifications; Chrome and operating-system notification settings must allow delivery. Chrome must be running. Alarms may be delayed by sleep or browser scheduling; startup rechecks overdue reminders. A record saved after its reminder date can notify immediately. Each item/deadline/reminder-time is deduplicated after notification creation. Imports create new records, so overdue imports may notify again. A notification click opens the keeper in a tab.

Receipt references are plain text. Files, inboxes, and shopping accounts are not accessed.

## Data, backups, and permissions

All records stay in this Chrome profile, without cloud sync or analytics. There are no remote scripts or application backends. Uninstalling removes local data; export a backup first. Chrome's local-storage quota applies. Sensitive URLs and notes may appear in plain-text backups. Clipboard operations occur only on explicit Copy actions. Page capture/scanning/filling occurs only on the corresponding button actions.

Export backup downloads JSON. Import backup accepts this extension's version 1 format (under 16 MB, subject to available Chrome local storage) and adds records without replacing existing ones. Importing twice creates duplicates. Undo last deletion restores the most recently deleted item during this Chrome session, including after closing/reopening the panel. It will not overwrite an existing item. Export backups for longer-term recovery. Unfinished forms are saved temporarily per browser window in Chrome session storage; use Clear unsaved draft to reset them. Browser exit or extension reload/update can clear session drafts and undo history. Screenshots and template placeholder values are excluded from draft recovery. Reading drafts preserve source URL/title alongside the passage. Imported backup dates are preserved; imports still assign new record IDs.

Permissions:

- `storage`: save records and user-controlled backups in this Chrome profile.
- `sidePanel`: display the interface beside the page.
- `activeTab`: temporarily access the current website after the toolbar icon is clicked.
- `alarms`: schedule and recheck local reminders.
- `notifications`: display local reminder notifications.

## Release status

This is an unpacked developer build, not a published Chrome Web Store extension. Publishing still requires a developer account, confirmed publisher name, listing assets, privacy disclosures, manual testing in a normal Chrome installation, and Google review. The ZIP has `manifest.json` at its root for future store upload preparation.

See the suite's TEST-REPORT.txt for what was tested and its limits.

## New in 0.2.0

Export active deadlines to calendar downloads an .ics file with separate all-day events for return and warranty deadlines, including lead-day reminder requests. Import it into your calendar manually. This is a snapshot, not a live sync; calendar reminder behavior depends on the client. Chrome reminders remain separate and use 9 AM local time.

## Fixed in 0.2.1

Backup imports support up to 16 MB and preserve record dates. Form submissions block concurrent edits and duplicate submission. See the suite release notes for extension-specific fixes.
