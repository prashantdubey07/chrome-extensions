let draftKey='',fields=[],writeQueue=Promise.resolve();
export function captureDraft(){
 if(!draftKey)return;
 const values=Object.fromEntries(fields.map(field=>[field.id,field.type==='checkbox'?field.checked:field.value]));
 // Queue writes in event order; drafts never include screenshots or page field values.
 writeQueue=writeQueue.then(()=>chrome.storage.session.set({[draftKey]:values})).catch(console.error);
}
export async function rememberDeletion(item){await chrome.storage.session.set({lastDeleted:{item,at:Date.now()}});}
export async function setupRecovery(notify,render){
 const heading=document.getElementById('form-heading');const defaultHeading=heading?.textContent;
 const undo=document.createElement('button');undo.id='undo-delete';undo.type='button';undo.textContent='Undo last deletion';undo.hidden=true;
 document.querySelector('footer').append(document.createElement('br'),undo);
 async function updateUndo(){const {lastDeleted}=await chrome.storage.session.get('lastDeleted');undo.hidden=!lastDeleted;}
 undo.addEventListener('click',async()=>{undo.disabled=true;try{
  const {lastDeleted}=await chrome.storage.session.get('lastDeleted');if(!lastDeleted)return;
  const key='record:'+lastDeleted.item.id;const existing=await chrome.storage.local.get(key);
  if(existing[key])throw Error('This item already exists; it was not overwritten.');
  await chrome.storage.local.set({[key]:lastDeleted.item});await chrome.storage.session.remove('lastDeleted');await render();notify('Deleted item restored.');
 }catch(error){notify(error.message,true);}finally{undo.disabled=false;}});
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='session'&&changes.lastDeleted)updateUndo().catch(console.error);});await updateUndo();
 const window=await chrome.windows.getCurrent();draftKey='draft:'+window.id;
 fields=[...document.querySelectorAll('form input,form textarea,form select,[data-draft]')].filter(field=>field.id&&!['file','password','submit','button'].includes(field.type));
 const stored=await chrome.storage.session.get(draftKey);const draft=stored[draftKey];
 if(draft){for(const field of fields){if(Object.hasOwn(draft,field.id)){if(field.type==='checkbox')field.checked=draft[field.id]===true;else field.value=String(draft[field.id]);}}
  const editing=document.getElementById('edit-id')?.value||document.getElementById('answer-id')?.value;
  if(editing){if(document.getElementById('cancel-edit'))document.getElementById('cancel-edit').hidden=false;if(document.getElementById('form-heading'))document.getElementById('form-heading').textContent='Continue editing';}
 }
 document.dispatchEvent(new Event('draft-restored'));
 document.addEventListener('input',captureDraft);document.addEventListener('change',captureDraft);document.addEventListener('focusin',captureDraft);
 for(const form of document.forms)form.addEventListener('reset',()=>setTimeout(captureDraft,0));
 const clear=document.createElement('button');clear.id='clear-draft';clear.type='button';clear.textContent='Clear unsaved draft';
 clear.addEventListener('click',async()=>{for(const form of document.forms)form.reset();for(const field of fields){if(field.type==='hidden'||field.hasAttribute('data-draft'))field.value='';}if(document.getElementById('cancel-edit'))document.getElementById('cancel-edit').hidden=true;if(heading)heading.textContent=defaultHeading;document.dispatchEvent(new Event('draft-cleared'));captureDraft();notify('Unsaved draft cleared. Saved items are kept.');});
 document.querySelector('footer').append(document.createTextNode(' · '),clear);
}
