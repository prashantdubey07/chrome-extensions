# Bug Report in One Click

Version 0.2.1 — a standalone local developer build.

## Install

1. Extract the ZIP, or open this extension's folder from the complete suite.
2. Open `chrome://extensions` in desktop Chrome and enable **Developer mode**.
3. Click **Load unpacked** and choose the folder containing this extension's `manifest.json`.
4. Pin the extension in the puzzle-piece menu and click its toolbar icon to open the side panel.

Requires Chrome 116 or newer. No build step, account, API key, or subscription is needed. Chrome's AI requirements apply separately to Explain This Page.

For page access, click the toolbar icon while on the website. If you navigate to another website, click the icon again to grant access there. No permanent website host permissions are requested. Chrome internal pages, incognito, and local files are not supported.

## Use it

On a web page with a problem, click the extension's toolbar icon, then **Capture page & screenshot**. It captures the visible browser-page viewport, URL, title, browser user-agent, viewport/screen dimensions, pixel ratio, and timestamp. It does not collect console logs, network requests, cookies, or browsing history.

Drag across the screenshot to cover private details with a solid rectangle. **Reset redactions** restores the in-memory original; **Remove screenshot** clears it. **Download screenshot** exports only the current canvas, including redactions. Keep private information out of the visible screenshot before sharing it.

Add steps to reproduce, expected behavior, actual behavior, severity, and frequency. **Save report text** stores the text locally; clicking it again updates that report. Edit, copy, search, or download saved reports as Markdown. No issue is submitted or sent automatically.

Screenshots are intentionally kept in memory, not in saved records or backups. Closing/reloading the panel loses the screenshot. Download it separately to preserve it. **Download current report as Markdown** includes a reference to the separately downloaded screenshot filename when a screenshot exists; keep both files in the same folder. A saved report downloaded from the library contains its text only.

Protected browser pages and the Chrome Web Store may block capture or script injection. Capture supports regular HTTP/HTTPS pages only. Scroll to the part of the page you want; full-page stitching is not included. This version does not provide a keyboard-driven redaction editor.

## Data, backups, and permissions

All records stay in this Chrome profile, without cloud sync or analytics. There are no remote scripts or application backends. Uninstalling removes local data; export a backup first. Chrome's local-storage quota applies. Sensitive URLs and notes may appear in plain-text backups. Clipboard operations occur only on explicit Copy actions. Page capture/scanning/filling occurs only on the corresponding button actions.

Export backup downloads JSON. Import backup accepts this extension's version 1 format (under 16 MB, subject to available Chrome local storage) and adds records without replacing existing ones. Importing twice creates duplicates. Undo last deletion restores the most recently deleted item during this Chrome session, including after closing/reopening the panel. It will not overwrite an existing item. Export backups for longer-term recovery. Unfinished forms are saved temporarily per browser window in Chrome session storage; use Clear unsaved draft to reset them. Browser exit or extension reload/update can clear session drafts and undo history. Screenshots and template placeholder values are excluded from draft recovery. Reading drafts preserve source URL/title alongside the passage. Imported backup dates are preserved; imports still assign new record IDs.

Permissions:

- `storage`: save records and user-controlled backups in this Chrome profile.
- `sidePanel`: display the interface beside the page.
- `activeTab`: temporarily access the current website after the toolbar icon is clicked.
- `scripting`: read the explicitly requested page information or fill a field the user chooses.

## Release status

This is an unpacked developer build, not a published Chrome Web Store extension. Publishing still requires a developer account, confirmed publisher name, listing assets, privacy disclosures, manual testing in a normal Chrome installation, and Google review. The ZIP has `manifest.json` at its root for future store upload preparation.

See the suite's TEST-REPORT.txt for what was tested and its limits.

## New in 0.2.0

Download report + screenshot ZIP packages Markdown and the currently redacted PNG together. Undo last redaction removes only the latest covered rectangle. Start new report clears the current text and screenshot, keeping saved reports. Opening another saved report clears the previous screenshot to avoid attaching it to the wrong report.

## Fixed in 0.2.1

Backup imports support up to 16 MB and preserve record dates. Form submissions block concurrent edits and duplicate submission. See the suite release notes for extension-specific fixes.
