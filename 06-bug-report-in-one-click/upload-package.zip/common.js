
import {setupRecovery,rememberDeletion,captureDraft} from './recovery.js';
export const $=id=>document.getElementById(id);
export function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e;}
export function notify(message,error=false){$('notice').hidden=false;$('notice').textContent=message;$('notice').classList.toggle('error',error);}
export function on(id,fn){$(id).addEventListener('click',async event=>{const button=event.currentTarget;button.disabled=true;try{await fn(event);}catch(error){notify(error.message||String(error),true);}finally{button.disabled=false;captureDraft();}});}
export function submit(id,fn){const form=$(id);let pending=false;form.addEventListener('submit',async event=>{event.preventDefault();if(pending)return;pending=true;const controls=[...form.elements].map(control=>({control,disabled:control.disabled}));for(const {control} of controls)control.disabled=true;try{await fn(event);}catch(error){notify(error.message||String(error),true);}finally{for(const {control,disabled} of controls)control.disabled=disabled;pending=false;captureDraft();}});}
export function action(text,fn,cls=''){const b=el('button',cls,text);b.type='button';b.addEventListener('click',async()=>{b.disabled=true;try{await fn();}catch(error){notify(error.message,true);}finally{b.disabled=false;captureDraft();}});return b;}
export function text(value,max=2000){return String(value??'').slice(0,max);}
export function required(value,label,max=160){const v=text(value,max).trim();if(!v)throw Error(`${label} is required.`);return v;}
export function webUrl(value,optional=false){if(!value&&optional)return '';try{const u=new URL(value);if(['http:','https:'].includes(u.protocol))return u.href;}catch{}throw Error('Use a complete http or https website URL.');}
export function date(value){if(!value)return '';if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(Date.parse(value+'T12:00:00'))||new Date(value+'T12:00:00Z').toISOString().slice(0,10)!==value)throw Error('Choose a valid date.');return value;}
export function localDay(value=new Date()){return [value.getFullYear(),String(value.getMonth()+1).padStart(2,'0'),String(value.getDate()).padStart(2,'0')].join('-');}
export async function currentTab(){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab||tab.incognito||!tab.url)throw Error('Open a regular web page, then click this extension’s toolbar icon to grant access.');if(!/^https?:/.test(tab.url))throw Error('This page is not supported. Open an http or https website and click the toolbar icon.');return tab;}
export async function inject(func,args=[]){const tab=await currentTab();try{const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func,args});return {tab,result:results[0]?.result};}catch{throw Error('Cannot access this page. Click the extension’s toolbar icon on the website and try again. Chrome internal pages and some protected pages are not supported.');}}
export async function download(name,content,type='application/json'){const blob=content instanceof Blob?content:new Blob([content],{type});const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),30000);}
export async function copy(value){await navigator.clipboard.writeText(value);notify('Copied to clipboard.');}
let validate,appId,renderFn;
function timestamp(value,fallback){return typeof value==='string'&&Number.isFinite(Date.parse(value))?new Date(value).toISOString():fallback;}
export async function records(){const all=await chrome.storage.local.get(null);return Object.entries(all).filter(([k])=>k.startsWith('record:')).map(([,v])=>v).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
export async function save(raw){const clean=validate(raw);const now=new Date().toISOString();const item={...clean,id:raw.id||crypto.randomUUID(),createdAt:raw.createdAt||now,updatedAt:now};await chrome.storage.local.set({['record:'+item.id]:item});return item;}
export async function remove(item){await rememberDeletion(item);await chrome.storage.local.remove('record:'+item.id);notify('Removed. Use Undo last deletion below to restore it.');}
export function search(items,q){q=q.trim().toLowerCase();return items.filter(item=>JSON.stringify(item).toLowerCase().includes(q));}
export function card(title,meta){const c=el('article','card');c.append(el('h3','',title));if(meta)c.append(el('p','meta',meta));return c;}
export function link(url,label){const a=el('a','',label);a.href=webUrl(url);a.target='_blank';a.rel='noopener noreferrer';return a;}
export function empty(parent,message){parent.replaceChildren(el('p','empty',message));}
export async function init(id,schema,render){appId=id;validate=schema;renderFn=render;
 on('backup',async()=>{await download(appId+'-backup.json',JSON.stringify({app:appId,version:1,records:await records()}));notify('Backup downloaded. It contains your saved data in plain text.');});
 on('restore',async()=>$('backup-file').click());
 $('backup-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>16*1024*1024)throw Error('Choose a backup smaller than 16 MB.');const data=JSON.parse(await file.text());if(data?.app!==appId||data.version!==1||!Array.isArray(data.records))throw Error('This is not a compatible backup for this extension.');const now=new Date().toISOString();const items=data.records.map(raw=>({...validate(raw),id:crypto.randomUUID(),createdAt:timestamp(raw.createdAt,now),updatedAt:timestamp(raw.updatedAt,now)}));await chrome.storage.local.set(Object.fromEntries(items.map(item=>['record:'+item.id,item])));await renderFn();notify(`Imported ${items.length} items. Existing items kept.`);}catch(error){notify(error.message,true);}finally{e.target.value='';}});
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&Object.keys(changes).some(key=>key.startsWith('record:')))renderFn().catch(error=>notify(error.message,true));});
 await renderFn();await setupRecovery(notify,renderFn);
}
