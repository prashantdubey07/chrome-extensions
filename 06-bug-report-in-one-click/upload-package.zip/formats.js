export function templateKeys(template){return [...new Set([...template.matchAll(/{{\s*([A-Za-z][A-Za-z0-9_ ]{0,39}?)\s*}}/g)].map(match=>match[1].trim()))];}
export function resolveTemplate(template,values){const output=template.replace(/{{\s*([A-Za-z][A-Za-z0-9_ ]{0,39}?)\s*}}/g,(_,key)=>{key=key.trim();const value=values.get(key);if(!value?.trim())throw Error(`Enter a value for ${key}.`);return value;});if(output.length>10000)throw Error('The prepared answer is too long (maximum 10,000 characters).');return output;}
export function csv(rows){const field=value=>{let valueText=String(value??'');if(/^[\s\uFEFF]*[=+@-]/u.test(valueText)||/^[\t\r\n]/.test(valueText))valueText="'"+valueText;return '"'+valueText.replaceAll('"','""')+'"';};return '\uFEFF'+rows.map(row=>row.map(field).join(',')).join('\r\n')+'\r\n';}
function icsEscape(value){return String(value).replaceAll('\\','\\\\').replace(/\r\n|\r|\n/g,'\\n').replaceAll(';','\\;').replaceAll(',','\\,');}
function fold(line){let bytes=0,part='',out=[];for(const char of line){const count=new TextEncoder().encode(char).length;if(bytes+count>75){out.push(part);part=' ';bytes=1;}part+=char;bytes+=count;}out.push(part);return out.join('\r\n');}
export function calendar(records){const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z/,'Z');const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Helpful Extensions//Return Keeper 0.2//EN','CALSCALE:GREGORIAN'];
 for(const item of records.filter(record=>record.state==='active'))for(const [key,label] of [['returnDate','Return deadline'],['warrantyDate','Warranty ends']]){
  if(!item[key])continue;const next=new Date(item[key]+'T12:00:00Z');if(!Number.isFinite(next.getTime()))throw Error('Invalid calendar deadline.');next.setUTCDate(next.getUTCDate()+1);
  lines.push('BEGIN:VEVENT',`UID:${icsEscape(item.id)}-${key}@return-keeper.local`,`DTSTAMP:${stamp}`,`DTSTART;VALUE=DATE:${item[key].replaceAll('-','')}`,`DTEND;VALUE=DATE:${next.toISOString().slice(0,10).replaceAll('-','')}`,`SUMMARY:${icsEscape(label+': '+item.product)}`,`DESCRIPTION:${icsEscape(item.store+(item.notes?'\n'+item.notes:''))}`);
  if(item.url)lines.push(`URL:${icsEscape(item.url)}`);
  lines.push('BEGIN:VALARM',`TRIGGER:-P${[1,3,7].includes(item.leadDays)?item.leadDays:3}D`,'ACTION:DISPLAY',`DESCRIPTION:${icsEscape(label+': '+item.product)}`,'END:VALARM','END:VEVENT');
 }
 lines.push('END:VCALENDAR');return lines.map(fold).join('\r\n')+'\r\n';
}
