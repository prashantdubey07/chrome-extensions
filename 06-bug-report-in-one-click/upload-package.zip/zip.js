// Small ZIP writer using uncompressed entries. PNGs are already compressed.
// No external dependency or network request is required.
const encoder=new TextEncoder();
function crc32(bytes){let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
export function zipFiles(files){
 const local=[],central=[];let offset=0,centralSize=0;
 for(const file of files){if(!/^[A-Za-z0-9_.-]+$/.test(file.name)||file.name==='..')throw Error('Unsupported attachment filename.');const name=encoder.encode(file.name);const bytes=file.bytes instanceof Uint8Array?file.bytes:encoder.encode(file.bytes);if(bytes.length>20*1024*1024)throw Error('Attachment is too large.');const crc=crc32(bytes);
  const header=new Uint8Array(30+name.length);const h=new DataView(header.buffer);h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(12,0x21,true);h.setUint32(14,crc,true);h.setUint32(18,bytes.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,name.length,true);header.set(name,30);local.push(header,bytes);
  const entry=new Uint8Array(46+name.length);const c=new DataView(entry.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(14,0x21,true);c.setUint32(16,crc,true);c.setUint32(20,bytes.length,true);c.setUint32(24,bytes.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);entry.set(name,46);central.push(entry);centralSize+=entry.length;offset+=header.length+bytes.length;
 }
 const end=new Uint8Array(22);const e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,centralSize,true);e.setUint32(16,offset,true);
 return new Blob([...local,...central,end],{type:'application/zip'});
}
