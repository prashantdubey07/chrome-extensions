# Job Application Tracker

Version 0.2.1 — a standalone local developer build.

## Install

1. Extract the ZIP, or open this extension's folder from the complete suite.
2. Open `chrome://extensions` in desktop Chrome and enable **Developer mode**.
3. Click **Load unpacked** and choose the folder containing this extension's `manifest.json`.
4. Pin the extension in the puzzle-piece menu and click its toolbar icon to open the side panel.

Requires Chrome 116 or newer. No build step, account, API key, or subscription is needed. Chrome's AI requirements apply separately to Explain This Page.

For page access, click the toolbar icon while on the website. If you navigate to another website, click the icon again to grant access there. No permanent website host permissions are requested. Chrome internal pages, incognito, and local files are not supported.

## Use it

Open a job listing and click the extension's toolbar icon. **Use this page's title & URL** copies those two details into the form; confirm them and add the company yourself. Alternatively, enter everything manually.

Save the application status, application date, notes, and an optional follow-up date and time. Search and filter opportunities, and use **Edit / update status** to change them. Follow-up times use the local timezone when entered and are saved as an absolute instant. Offer, Rejected, and Withdrawn statuses stop follow-up reminders.

Follow-ups use Chrome alarms and local notifications. Chrome and operating-system notification settings must allow delivery. Chrome must be running; reminders can be delayed by sleep or browser scheduling. Startup rechecks overdue reminders, and sent reminders are deduplicated for each record/time. Imported backups create new records and may trigger overdue reminders again. A notification click opens the tracker in a tab. Capturing a title does not extract or submit application forms.

## Data, backups, and permissions

All records stay in this Chrome profile, without cloud sync or analytics. There are no remote scripts or application backends. Uninstalling removes local data; export a backup first. Chrome's local-storage quota applies. Sensitive URLs and notes may appear in plain-text backups. Clipboard operations occur only on explicit Copy actions. Page capture/scanning/filling occurs only on the corresponding button actions.

Export backup downloads JSON. Import backup accepts this extension's version 1 format (under 16 MB, subject to available Chrome local storage) and adds records without replacing existing ones. Importing twice creates duplicates. Undo last deletion restores the most recently deleted item during this Chrome session, including after closing/reopening the panel. It will not overwrite an existing item. Export backups for longer-term recovery. Unfinished forms are saved temporarily per browser window in Chrome session storage; use Clear unsaved draft to reset them. Browser exit or extension reload/update can clear session drafts and undo history. Screenshots and template placeholder values are excluded from draft recovery. Reading drafts preserve source URL/title alongside the passage. Imported backup dates are preserved; imports still assign new record IDs.

Permissions:

- `storage`: save records and user-controlled backups in this Chrome profile.
- `sidePanel`: display the interface beside the page.
- `activeTab`: temporarily access the current website after the toolbar icon is clicked.
- `alarms`: schedule and recheck local reminders.
- `notifications`: display local reminder notifications.

## Release status

This is an unpacked developer build, not a published Chrome Web Store extension. Publishing still requires a developer account, confirmed publisher name, listing assets, privacy disclosures, manual testing in a normal Chrome installation, and Google review. The ZIP has `manifest.json` at its root for future store upload preparation.

See the suite's TEST-REPORT.txt for what was tested and its limits.

## New in 0.2.0

Export matching jobs as CSV downloads the currently searched/filtered opportunities, with status, dates, URL, and notes. Formula-like text is prefixed with an apostrophe to prevent automatic formula execution in spreadsheet apps.

## Fixed in 0.2.1

Backup imports support up to 16 MB and preserve record dates. Form submissions block concurrent edits and duplicate submission. See the suite release notes for extension-specific fixes.
