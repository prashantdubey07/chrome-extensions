export function reminders(record){
 if(!Number.isFinite(record.reminderAt)||record.reminderAt<=0||['Offer','Rejected','Withdrawn'].includes(record.stage))return [];
 return [{key:'followup',when:record.reminderAt,title:'Time to follow up',message:`${record.title} at ${record.company}`}];
}
