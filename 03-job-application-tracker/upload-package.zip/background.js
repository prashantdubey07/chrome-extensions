import {reminders} from './reminders.js';
chrome.action.onClicked.addListener(tab=>chrome.sidePanel.open({windowId:tab.windowId}).catch(console.error));
let running=null,again=false;
export async function checkReminders(){if(running){again=true;return running;}running=(async()=>{do{again=false;await run();}while(again);})().finally(()=>running=null);return running;}
async function run(){
 const all=await chrome.storage.local.get(null);const now=Date.now();let next=Infinity;
 for(const [key,record] of Object.entries(all)){
  if(!key.startsWith('record:'))continue;
  for(const reminder of reminders(record)){
   const marker=`sent:${record.id}:${reminder.key}:${reminder.when}`;
   if(all[marker])continue;
   if(reminder.when>now){next=Math.min(next,reminder.when);continue;}
   await chrome.notifications.create(`${record.id}:${reminder.key}`,{type:'basic',iconUrl:'icons/128.png',title:reminder.title,message:reminder.message,priority:1});
   await chrome.storage.local.set({[marker]:now});
  }
 }
 await chrome.alarms.clear('next-due');
 if(Number.isFinite(next))await chrome.alarms.create('next-due',{when:Math.max(next,Date.now()+1000)});
}
async function setup(){await chrome.alarms.create('reminder-check',{periodInMinutes:60});await checkReminders();}
chrome.runtime.onInstalled.addListener(()=>setup().catch(console.error));
chrome.runtime.onStartup.addListener(()=>setup().catch(console.error));
chrome.alarms.onAlarm.addListener(()=>checkReminders().catch(console.error));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&Object.keys(changes).some(key=>key.startsWith('record:')))checkReminders().catch(console.error);});
chrome.notifications.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('panel.html')}).catch(console.error));
