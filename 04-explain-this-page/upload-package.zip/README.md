# Explain This Page

Version 0.2.1 — a standalone local developer build.

## Install

1. Extract the ZIP, or open this extension's folder from the complete suite.
2. Open `chrome://extensions` in desktop Chrome and enable **Developer mode**.
3. Click **Load unpacked** and choose the folder containing this extension's `manifest.json`.
4. Pin the extension in the puzzle-piece menu and click its toolbar icon to open the side panel.

Requires Chrome 138 or newer. No build step, account, API key, or subscription is needed. Chrome's AI requirements apply separately to Explain This Page.

For page access, click the toolbar icon while on the website. If you navigate to another website, click the icon again to grant access there. No permanent website host permissions are requested. Chrome internal pages, incognito, and local files are not supported.

## Use it

Select a passage on a website, click the extension's toolbar icon, and choose **Use selected text**. **Use page article** reads the first article/main region (or the page body). You can also paste text directly. Review the captured text before using AI. Page extraction supports the top-level document, not PDFs, cross-origin frames, or shadow DOM.

This version expects English source text, up to 12,000 characters. Choose Explain simply, Summarize key points, or Translate, and an output language: English, Spanish, Japanese, German, or French. Click **Enable on-device AI** to initialize Chrome's built-in Prompt API, then run the task. Chrome may need to download a model. Its hardware, language, storage, browser-version, and administrator-policy requirements still apply. Changing output language requires enabling the model again.

If Chrome reports AI unavailable, **Show readable source excerpts (no AI)** displays the first eight source sentences. These are explicitly labeled source excerpts, not generated explanations. This path works without a model or API key. Copy results, save them to the reading library, or delete saved notes. Saved reading notes stay local. Unfinished source text is also kept temporarily in Chrome session storage for draft recovery.

AI output can be inaccurate; check it against the source. The extension does not call a hosted AI service. Built-in AI support: https://developer.chrome.com/docs/ai/prompt-api

## AI validation limit

The isolated test browser exposed LanguageModel but reported availability as unavailable. Actual model generation and translation were not exercised. The API adapter was tested with a deterministic stub; source extraction, fallback, library, and backup flows ran in the loaded extension. Test real AI output on a compatible machine before publishing.

## Data, backups, and permissions

All records stay in this Chrome profile, without cloud sync or analytics. There are no remote scripts or application backends. Uninstalling removes local data; export a backup first. Chrome's local-storage quota applies. Sensitive URLs and notes may appear in plain-text backups. Clipboard operations occur only on explicit Copy actions. Page capture/scanning/filling occurs only on the corresponding button actions.

Export backup downloads JSON. Import backup accepts this extension's version 1 format (under 16 MB, subject to available Chrome local storage) and adds records without replacing existing ones. Importing twice creates duplicates. Undo last deletion restores the most recently deleted item during this Chrome session, including after closing/reopening the panel. It will not overwrite an existing item. Export backups for longer-term recovery. Unfinished forms are saved temporarily per browser window in Chrome session storage; use Clear unsaved draft to reset them. Browser exit or extension reload/update can clear session drafts and undo history. Screenshots and template placeholder values are excluded from draft recovery. Reading drafts preserve source URL/title alongside the passage. Imported backup dates are preserved; imports still assign new record IDs.

Permissions:

- `storage`: save records and user-controlled backups in this Chrome profile.
- `sidePanel`: display the interface beside the page.
- `activeTab`: temporarily access the current website after the toolbar icon is clicked.
- `scripting`: read the explicitly requested page information or fill a field the user chooses.

## Release status

This is an unpacked developer build, not a published Chrome Web Store extension. Publishing still requires a developer account, confirmed publisher name, listing assets, privacy disclosures, manual testing in a normal Chrome installation, and Google review. The ZIP has `manifest.json` at its root for future store upload preparation.

See the suite's TEST-REPORT.txt for what was tested and its limits.

## New in 0.2.0

Saved results retain the source passage and URL used when the result was created, even if the input changes afterward. Open the original source or export a saved reading note as Markdown. Input controls are locked during generation. Model initialization failures leave generation disabled and source excerpts available.

## Fixed in 0.2.1

Backup imports support up to 16 MB and preserve record dates. Form submissions block concurrent edits and duplicate submission. See the suite release notes for extension-specific fixes.
